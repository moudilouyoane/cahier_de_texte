package projetpoo;

importjava.util.Date;
public class Seance {
	private String titreCours;
	private Date date;
	private int duree;
	private String contenu;
	private String observations;
	private boolean estvalidee;
	
	public Seance(String titreCours, int duree, String contenu) {
		this.titreCours = titreCours;
		this.date = new Date();
		this.duree = duree;
		this.contenu = contenu;
		this.estvalidee = false;
	}

	public String getTitreCours() {
		return titreCours;
	}

	public void setTitreCours(String titreCours) {
		this.titreCours = titreCours;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public String getObservations() {
		return observations;
	}

	public void setObservations(String observations) {
		this.observations = observations;
	}

	public boolean isEstvalidee() {
		return estvalidee;
	}

	public void setEstvalidee(boolean estvalidee) {
		this.estvalidee = estvalidee;
	}
}
