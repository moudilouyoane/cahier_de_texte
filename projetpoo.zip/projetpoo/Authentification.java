package projetpoo;

import java.util.ArrayList;

public class Authentification {
    
    public static User login(ArrayList<User> base, String login, String mdp) {
        for (User u : base) {
            if (u.getLogin().equals(login) && u.getPassword().equals(mdp)) {
                return u;
            }
        }
        return null; 
    }
}
