package projetpoo;

public enum Role {
    CHEF, ENSEIGNANT, RESPONSABLE;
}