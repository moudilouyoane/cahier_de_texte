package projetpoo;

public class User {
    private String login;
    private String password;
    private String nom;
    private String prenom;
    private String role;

    public User(String login, String nom, String prenom, String role, String password) {
        this.login = login;
        this.nom = nom;
        this.prenom = prenom;
        this.role = role;
        this.password = password;
    }

    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getPassword() { return password; }
    public String getLogin() {
    	return login;
    }

    public void setPassword(String password) throws Exception {
        if (password != null && password.length() == 11) {
            this.password = password;
        } else {
            throw new Exception("Le mot de passe doit faire 11 caracteres !");
        }
    }
}