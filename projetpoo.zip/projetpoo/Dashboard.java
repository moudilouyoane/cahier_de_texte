package projetpoo;

import javax.swing.JOptionPane;

public class Dashboard {
    
    public static void afficherMenu(User utilisateurConnecte) {
        String message = "Bienvenue " + utilisateurConnecte.getPrenom() + "\n";
        message += "Votre r�le : " + utilisateurConnecte.getRole() + "\n\n";
        
        if (utilisateurConnecte.getRole().equalsIgnoreCase("Chef")) {
            message += "1. Valider les comptes\n2. Consulter les statistiques globales";
        } else if (utilisateurConnecte.getRole().equalsIgnoreCase("Enseignant")) {
            message += "1. Cr�er une fiche de suivi\n2. Consulter mes cours";
        }
        
        JOptionPane.showMessageDialog(null, message);
    }
}
