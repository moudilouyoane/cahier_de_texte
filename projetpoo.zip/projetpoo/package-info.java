public class MotDePasseInvalideException extends Exeption {
	public MotDePasseInvalideException(string message) {
		super(message);
	}
}