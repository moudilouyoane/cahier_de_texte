package projetpoo;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class UserManager {
    public static void main(String[] args) {
        ArrayList<User> baseDeDonnees = new ArrayList<>();

        for (int i = 0; i < 2; i++) {
            String login = JOptionPane.showInputDialog("Entrez le login :");
            String nom = JOptionPane.showInputDialog("Entrez le nom :");
            String prenom = JOptionPane.showInputDialog("Entrez le prenom :");
            String role = JOptionPane.showInputDialog("Role (Chef/Enseignant/Responsable) :");
            String password = JOptionPane.showInputDialog("Choisissez votre mot de passe :");

            User u = new User(login, nom, prenom, role, password);
            baseDeDonnees.add(u);

            JOptionPane.showMessageDialog(null, "Utilisateur cree avec succes !\n" +
                    "Nom complet : " + u.getPrenom() + " " + u.getNom() + "\n" +
                    "Nombre d'utilisateurs dans la liste : " + baseDeDonnees.size());

            boolean success = false;
            while (!success) {
                String nouveauMdp = JOptionPane.showInputDialog("Veuillez definir un mot de passe de 11 caracteres :");
                try {
                    u.setPassword(nouveauMdp);
                    JOptionPane.showMessageDialog(null, "Mot de passe mis a jour !");
                    success = true;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage(), "Erreur de securite", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        
        System.out.println("Liste finale des utilisateurs :");
        for (User user : baseDeDonnees) {
            System.out.println(user.getNom() + " " + user.getPrenom() + " (" + user.getLogin() + ")");
        }
    }
}