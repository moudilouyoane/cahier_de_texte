package projetpoo;

import java.util.ArrayList;

public class Cours {
    private String nomCours;
    private User enseignantResponsable;
    private ArrayList<Seance> listeFiches;

    public Cours(String nomCours, User enseignant) {
        this.nomCours = nomCours;
        this.enseignantResponsable = enseignant;
        this.listeFiches = new ArrayList<>();
    }

    public void ajouterSeance(Seance s) {
        this.listeFiches.add(s);
    }

    public String getNomCours() { return nomCours; }
    public User getEnseignant() { return enseignantResponsable; }
    public ArrayList<Seance> getListeFiches() { return listeFiches; }
}
